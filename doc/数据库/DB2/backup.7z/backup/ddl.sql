-- �� CLP �ļ���ʹ�� DB2LOOK �汾 "9.7" ������ 
-- ʱ�����: 2016/2/2 9:27:53
-- ���ݿ�����: UIBV2          
-- ���ݿ�������汾: DB2/NT Version 9.7.0          
-- ���ݿ����ҳ: 1208
-- ���ݿ�����˳��Ϊ: IDENTITY


CONNECT TO UIBV2 USER ADMINISTRATOR;



------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."TEST_BLOG"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."TEST_BLOG"  (
		  "IDS" VARCHAR(32) NOT NULL , 
		  "TITLE" VARCHAR(200) , 
		  "CONTENT" CLOB(1048576) LOGGED NOT COMPACT , 
		  "CREATETIME" TIMESTAMP )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."TEST_BLOG"

ALTER TABLE "ADMINISTRATOR"."TEST_BLOG" 
	ADD PRIMARY KEY
		("IDS");


------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."PT_DEPARTMENT"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."PT_DEPARTMENT"  (
		  "IDS" VARCHAR(32) NOT NULL , 
		  "VERSION" BIGINT , 
		  "ALLCHILDNODEIDS" VARCHAR(2000) , 
		  "DEPARTMENTLEVEL" BIGINT , 
		  "DEPTTYPE" CHAR(1) , 
		  "DESCRIPTION" VARCHAR(200) , 
		  "IMAGES" VARCHAR(50) , 
		  "ISPARENT" VARCHAR(5) , 
		  "NAMES" VARCHAR(25) , 
		  "ORDERIDS" BIGINT , 
		  "URL" VARCHAR(100) , 
		  "PARENTDEPARTMENTIDS" VARCHAR(32) , 
		  "PRINCIPALUSERIDS" VARCHAR(32) )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."PT_DEPARTMENT"

ALTER TABLE "ADMINISTRATOR"."PT_DEPARTMENT" 
	ADD PRIMARY KEY
		("IDS");


------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."PT_GROUP"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."PT_GROUP"  (
		  "IDS" VARCHAR(32) NOT NULL , 
		  "VERSION" BIGINT , 
		  "DESCRIPTION" VARCHAR(2000) , 
		  "NAMES" VARCHAR(50) , 
		  "ROLEIDS" CLOB(1048576) LOGGED NOT COMPACT , 
		  "NUMBERS" VARCHAR(50) )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."PT_GROUP"

ALTER TABLE "ADMINISTRATOR"."PT_GROUP" 
	ADD PRIMARY KEY
		("IDS");


------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."PT_MENU"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."PT_MENU"  (
		  "IDS" VARCHAR(32) NOT NULL , 
		  "VERSION" BIGINT , 
		  "IMAGES" VARCHAR(50) , 
		  "LEVELS" BIGINT , 
		  "ORDERIDS" BIGINT , 
		  "OPERATORIDS" VARCHAR(32) , 
		  "PARENTMENUIDS" VARCHAR(32) , 
		  "SYSTEMSIDS" VARCHAR(32) , 
		  "ISPARENT" VARCHAR(5) , 
		  "NAMES_ZHCN" VARCHAR(25) , 
		  "NAMES_ZHHK" VARCHAR(25) , 
		  "NAMES_ZHTW" VARCHAR(25) , 
		  "NAMES_ENUS" VARCHAR(25) , 
		  "NAMES_JA" VARCHAR(25) , 
		  "PARAM" VARCHAR(200) )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."PT_MENU"

ALTER TABLE "ADMINISTRATOR"."PT_MENU" 
	ADD PRIMARY KEY
		("IDS");


------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."PT_MODULE"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."PT_MODULE"  (
		  "IDS" VARCHAR(32) NOT NULL , 
		  "VERSION" BIGINT , 
		  "DESCRIPTION" VARCHAR(200) , 
		  "IMAGES" VARCHAR(50) , 
		  "ISPARENT" VARCHAR(5) , 
		  "NAMES" VARCHAR(25) , 
		  "ORDERIDS" BIGINT , 
		  "PARENTMODULEIDS" VARCHAR(32) , 
		  "SYSTEMSIDS" VARCHAR(32) )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."PT_MODULE"

ALTER TABLE "ADMINISTRATOR"."PT_MODULE" 
	ADD PRIMARY KEY
		("IDS");


------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."PT_OPERATOR"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."PT_OPERATOR"  (
		  "IDS" VARCHAR(32) NOT NULL , 
		  "VERSION" BIGINT , 
		  "DESCRIPTION" VARCHAR(200) , 
		  "NAMES" VARCHAR(25) , 
		  "ONEMANY" CHAR(1) , 
		  "RETURNPARAMKEYS" VARCHAR(100) , 
		  "RETURNURL" VARCHAR(200) , 
		  "ROWFILTER" CHAR(1) , 
		  "URL" VARCHAR(200) , 
		  "MODULEIDS" VARCHAR(32) , 
		  "MODULENAMES" VARCHAR(50) , 
		  "SPLITPAGE" CHAR(1) , 
		  "FORMTOKEN" CHAR(1) , 
		  "IPBLACK" CHAR(1) , 
		  "PRIVILEGESS" CHAR(1) , 
		  "ISPV" CHAR(1) , 
		  "PVTYPE" CHAR(1) )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."PT_OPERATOR"

ALTER TABLE "ADMINISTRATOR"."PT_OPERATOR" 
	ADD PRIMARY KEY
		("IDS");


------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."PT_RESOURCES"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."PT_RESOURCES"  (
		  "IDS" VARCHAR(32) NOT NULL , 
		  "VERSION" BIGINT , 
		  "OSNAME" VARCHAR(200) , 
		  "IPS" VARCHAR(50) , 
		  "HOSTNAME" VARCHAR(200) , 
		  "CPUNUMBER" BIGINT , 
		  "CPURATIO" DECIMAL(20,10) , 
		  "PHYMEMORY" BIGINT , 
		  "PHYFREEMEMORY" BIGINT , 
		  "JVMTOTALMEMORY" BIGINT , 
		  "JVMFREEMEMORY" BIGINT , 
		  "JVMMAXMEMORY" BIGINT , 
		  "GCCOUNT" BIGINT , 
		  "CREATEDATE" TIMESTAMP )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."PT_RESOURCES"

ALTER TABLE "ADMINISTRATOR"."PT_RESOURCES" 
	ADD PRIMARY KEY
		("IDS");


------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."PT_ROLE"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."PT_ROLE"  (
		  "IDS" VARCHAR(32) NOT NULL , 
		  "VERSION" BIGINT , 
		  "NUMBERS" VARCHAR(50) , 
		  "NAMES" VARCHAR(50) , 
		  "DESCRIPTION" VARCHAR(2000) , 
		  "OPERATORIDS" CLOB(1048576) LOGGED NOT COMPACT , 
		  "MODULEIDS" CLOB(1048576) LOGGED NOT COMPACT )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."PT_ROLE"

ALTER TABLE "ADMINISTRATOR"."PT_ROLE" 
	ADD PRIMARY KEY
		("IDS");


------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."PT_STATION"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."PT_STATION"  (
		  "IDS" VARCHAR(32) NOT NULL , 
		  "VERSION" BIGINT , 
		  "DESCRIPTION" VARCHAR(200) , 
		  "IMAGES" VARCHAR(50) , 
		  "ISPARENT" VARCHAR(5) , 
		  "NAMES" VARCHAR(25) , 
		  "ORDERIDS" BIGINT , 
		  "PARENTSTATIONIDS" VARCHAR(32) , 
		  "OPERATORIDS" CLOB(1048576) LOGGED NOT COMPACT , 
		  "MODULEIDS" CLOB(1048576) LOGGED NOT COMPACT )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."PT_STATION"

ALTER TABLE "ADMINISTRATOR"."PT_STATION" 
	ADD PRIMARY KEY
		("IDS");


------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."PT_SYSTEMS"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."PT_SYSTEMS"  (
		  "IDS" VARCHAR(32) NOT NULL , 
		  "VERSION" BIGINT , 
		  "DESCRIPTION" VARCHAR(200) , 
		  "NAMES" VARCHAR(25) , 
		  "NUMBERS" VARCHAR(25) , 
		  "ORDERIDS" BIGINT )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."PT_SYSTEMS"

ALTER TABLE "ADMINISTRATOR"."PT_SYSTEMS" 
	ADD PRIMARY KEY
		("IDS");


------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."PT_UPLOAD"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."PT_UPLOAD"  (
		  "IDS" VARCHAR(32) NOT NULL , 
		  "VERSION" BIGINT , 
		  "PARAMETERNAME" VARCHAR(50) , 
		  "FILENAME" VARCHAR(50) , 
		  "CONTENTTYPE" VARCHAR(100) , 
		  "ORIGINALFILENAME" VARCHAR(500) , 
		  "PATH" VARCHAR(500) )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."PT_UPLOAD"

ALTER TABLE "ADMINISTRATOR"."PT_UPLOAD" 
	ADD PRIMARY KEY
		("IDS");


------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."PT_USER"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."PT_USER"  (
		  "IDS" VARCHAR(32) NOT NULL , 
		  "VERSION" BIGINT , 
		  "ORDERIDS" BIGINT , 
		  "PASSWORD" BLOB(1048576) LOGGED NOT COMPACT , 
		  "ERRORCOUNT" BIGINT , 
		  "SALT" BLOB(1048576) LOGGED NOT COMPACT , 
		  "STATUS" CHAR(1) , 
		  "STOPDATE" TIMESTAMP NOT NULL WITH DEFAULT CURRENT TIMESTAMP , 
		  "USERNAME" VARCHAR(50) , 
		  "DEPARTMENTIDS" VARCHAR(32) , 
		  "DEPARTMENTNAMES" VARCHAR(25) , 
		  "USERINFOIDS" VARCHAR(32) , 
		  "STATIONIDS" CLOB(1048576) LOGGED NOT COMPACT , 
		  "STATIONNAMES" CLOB(1048576) LOGGED NOT COMPACT , 
		  "DEPTIDS" CLOB(1048576) LOGGED NOT COMPACT , 
		  "DEPTNAMES" CLOB(1048576) LOGGED NOT COMPACT , 
		  "USERIDS" CLOB(1048576) LOGGED NOT COMPACT , 
		  "USERNAMES" CLOB(1048576) LOGGED NOT COMPACT , 
		  "GROUPIDS" CLOB(1048576) LOGGED NOT COMPACT , 
		  "GROUPNAMES" CLOB(1048576) LOGGED NOT COMPACT )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."PT_USER"

ALTER TABLE "ADMINISTRATOR"."PT_USER" 
	ADD PRIMARY KEY
		("IDS");


------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."WX_ARTICLE"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."WX_ARTICLE"  (
		  "IDS" VARCHAR(32) NOT NULL , 
		  "MESSAGEIDS" VARCHAR(32) , 
		  "TITLE" VARCHAR(100) , 
		  "DESCRIPTION" CLOB(1048576) LOGGED NOT COMPACT , 
		  "PICURL" VARCHAR(500) , 
		  "URL" VARCHAR(500) )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."WX_ARTICLE"

ALTER TABLE "ADMINISTRATOR"."WX_ARTICLE" 
	ADD PRIMARY KEY
		("IDS");


------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."WX_FILE"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."WX_FILE"  (
		  "IDS" VARCHAR(32) NOT NULL )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."WX_FILE"

ALTER TABLE "ADMINISTRATOR"."WX_FILE" 
	ADD PRIMARY KEY
		("IDS");


------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."WX_GROUP"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."WX_GROUP"  (
		  "IDS" VARCHAR(32) NOT NULL , 
		  "ID" VARCHAR(50) , 
		  "NAME" VARCHAR(50) , 
		  "COUNT" DECIMAL(20,0) )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."WX_GROUP"

ALTER TABLE "ADMINISTRATOR"."WX_GROUP" 
	ADD PRIMARY KEY
		("IDS");


------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."WX_KEYWORD"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."WX_KEYWORD"  (
		  "IDS" VARCHAR(32) NOT NULL , 
		  "QUESTION" VARCHAR(500) , 
		  "QUESTIONKEY" VARCHAR(500) , 
		  "ANSWER" CLOB(1048576) LOGGED NOT COMPACT )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."WX_KEYWORD"

ALTER TABLE "ADMINISTRATOR"."WX_KEYWORD" 
	ADD PRIMARY KEY
		("IDS");


------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."WX_LOCATION"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."WX_LOCATION"  (
		  "IDS" VARCHAR(32) NOT NULL , 
		  "OPEN_ID" VARCHAR(32) , 
		  "LNG" VARCHAR(50) , 
		  "LAT" VARCHAR(50) , 
		  "BD09_LNG" VARCHAR(50) , 
		  "BD09_LAT" VARCHAR(50) , 
		  "CREATEDATE" TIMESTAMP NOT NULL WITH DEFAULT CURRENT TIMESTAMP )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."WX_LOCATION"

ALTER TABLE "ADMINISTRATOR"."WX_LOCATION" 
	ADD PRIMARY KEY
		("IDS");


------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."WX_ROLE"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."WX_ROLE"  (
		  "IDS" VARCHAR(32) NOT NULL )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."WX_ROLE"

ALTER TABLE "ADMINISTRATOR"."WX_ROLE" 
	ADD PRIMARY KEY
		("IDS");


------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."WX_USER"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."WX_USER"  (
		  "IDS" VARCHAR(32) NOT NULL , 
		  "OPENID" VARCHAR(50) , 
		  "SUBSCRIBE" CHAR(1) , 
		  "SUBSCRIBETIME" DECIMAL(20,0) , 
		  "NICKNAME" VARCHAR(50) , 
		  "SEX" CHAR(1) , 
		  "COUNTRY" VARCHAR(50) , 
		  "PROVINCE" VARCHAR(50) , 
		  "CITY" VARCHAR(50) , 
		  "LANGUAGE" VARCHAR(50) , 
		  "HEADIMGURL" VARCHAR(500) , 
		  "GROUPIDS" VARCHAR(32) )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."WX_USER"

ALTER TABLE "ADMINISTRATOR"."WX_USER" 
	ADD PRIMARY KEY
		("IDS");


------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."PT_DICT"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."PT_DICT"  (
		  "IDS" VARCHAR(32) NOT NULL , 
		  "VERSION" BIGINT , 
		  "DESCRIPTION" VARCHAR(200) , 
		  "IMAGES" VARCHAR(50) , 
		  "NAMES" VARCHAR(25) , 
		  "ORDERIDS" BIGINT , 
		  "PATHS" VARCHAR(500) , 
		  "ZHUANGTAI" CHAR(1) , 
		  "PARENTIDS" VARCHAR(32) , 
		  "ISPARENT" VARCHAR(5) , 
		  "LEVELS" BIGINT , 
		  "NUMBERS" VARCHAR(50) , 
		  "VAL" VARCHAR(500) , 
		  "I18N" CHAR(1) , 
		  "VAL_ZHCN" VARCHAR(500) , 
		  "VAL_ZHHK" VARCHAR(500) , 
		  "VAL_ZHTW" VARCHAR(500) , 
		  "VAL_JA" VARCHAR(500) , 
		  "VAL_ENUS" VARCHAR(500) , 
		  "STATUS" CHAR(1) )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."PT_DICT"

ALTER TABLE "ADMINISTRATOR"."PT_DICT" 
	ADD PRIMARY KEY
		("IDS");


------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."PT_PARAM"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."PT_PARAM"  (
		  "IDS" VARCHAR(32) NOT NULL , 
		  "VERSION" BIGINT , 
		  "DESCRIPTION" VARCHAR(200) , 
		  "IMAGES" VARCHAR(50) , 
		  "NAMES" VARCHAR(25) , 
		  "ORDERIDS" BIGINT , 
		  "PATHS" VARCHAR(500) , 
		  "ZHUANGTAI" CHAR(1) , 
		  "PARENTIDS" VARCHAR(32) , 
		  "ISPARENT" VARCHAR(5) , 
		  "LEVELS" BIGINT , 
		  "NUMBERS" VARCHAR(50) , 
		  "VAL" VARCHAR(500) , 
		  "I18N" CHAR(1) , 
		  "VAL_ZHCN" VARCHAR(500) , 
		  "VAL_ZHHK" VARCHAR(500) , 
		  "VAL_ZHTW" VARCHAR(500) , 
		  "VAL_JA" VARCHAR(500) , 
		  "VAL_ENUS" VARCHAR(500) , 
		  "STATUS" CHAR(1) )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."PT_PARAM"

ALTER TABLE "ADMINISTRATOR"."PT_PARAM" 
	ADD PRIMARY KEY
		("IDS");


------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."PT_USERINFO"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."PT_USERINFO"  (
		  "IDS" VARCHAR(32) NOT NULL , 
		  "VERSION" BIGINT , 
		  "ADDRESS" VARCHAR(300) , 
		  "ADDRESSINFO" VARCHAR(300) , 
		  "AVOIRDUPOIS" VARCHAR(5) , 
		  "BIRTHDAY" DATE , 
		  "BLOODGROUP" VARCHAR(15) , 
		  "CLIENTLEVELEND" TIMESTAMP , 
		  "CLIENTLEVELSTART" TIMESTAMP , 
		  "CULTURE" VARCHAR(30) , 
		  "DESCRIPTION" VARCHAR(200) , 
		  "EMAIL" VARCHAR(100) , 
		  "FINISHSCHOOLDATE" DATE , 
		  "FOLK" VARCHAR(20) , 
		  "GOVERNMENT" VARCHAR(25) , 
		  "HOMEPAGE" VARCHAR(100) , 
		  "HOUSEHOLDER" VARCHAR(20) , 
		  "IDCARD" VARCHAR(25) , 
		  "MARRIAGE" VARCHAR(20) , 
		  "MOBILE" VARCHAR(20) , 
		  "MSN" VARCHAR(20) , 
		  "NAMES" VARCHAR(25) , 
		  "NATIVITYADDRESS" VARCHAR(20) , 
		  "POSTBOY" VARCHAR(6) , 
		  "QQ" VARCHAR(20) , 
		  "SCHOOLNAME" VARCHAR(20) , 
		  "SEX" VARCHAR(5) , 
		  "SPECIALITY" VARCHAR(20) , 
		  "STATURE" VARCHAR(5) , 
		  "TELEPHONE" VARCHAR(20) )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."PT_USERINFO"

ALTER TABLE "ADMINISTRATOR"."PT_USERINFO" 
	ADD PRIMARY KEY
		("IDS");


------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."WX_MESSAGE"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."WX_MESSAGE"  (
		  "IDS" VARCHAR(32) NOT NULL , 
		  "INOUTS" CHAR(1) , 
		  "DATATYPE" CHAR(1) , 
		  "DATACONTENT" CLOB(1048576) LOGGED NOT COMPACT , 
		  "MSGTYPE" VARCHAR(50) , 
		  "EVENT" VARCHAR(50) , 
		  "EVENTKEY" VARCHAR(50) , 
		  "TOUSERNAME" VARCHAR(50) , 
		  "FROMUSERNAME" VARCHAR(50) , 
		  "CREATETIME" DECIMAL(20,0) , 
		  "MSGID" VARCHAR(64) , 
		  "PICURL" VARCHAR(200) , 
		  "MEDIAID" VARCHAR(200) , 
		  "TITLE" VARCHAR(100) , 
		  "DESCRIPTION" CLOB(1048576) LOGGED NOT COMPACT , 
		  "URL" VARCHAR(500) , 
		  "LOCATION_X" DECIMAL(20,10) , 
		  "LOCATION_Y" DECIMAL(20,10) , 
		  "SCALE" DECIMAL(20,0) , 
		  "LABELS" VARCHAR(50) , 
		  "CONTENT" CLOB(1048576) LOGGED NOT COMPACT , 
		  "THUMBMEDIAID" VARCHAR(500) , 
		  "FORMAT" VARCHAR(20) , 
		  "RECOGNITION" CLOB(1048576) LOGGED NOT COMPACT , 
		  "LATITUDE" DECIMAL(20,10) , 
		  "LONGITUDE" DECIMAL(20,10) , 
		  "PRECISIONS" DECIMAL(20,10) , 
		  "TICKET" CLOB(1048576) LOGGED NOT COMPACT , 
		  "MUSICURL" VARCHAR(500) , 
		  "HQMUSICURL" VARCHAR(500) , 
		  "ARTICLECOUNT" DECIMAL(2,0) )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."WX_MESSAGE"

ALTER TABLE "ADMINISTRATOR"."WX_MESSAGE" 
	ADD PRIMARY KEY
		("IDS");


------------------------------------------------
-- ���� DDL ��� "ADMINISTRATOR"."PT_SYSLOG"
------------------------------------------------
 

CREATE TABLE "ADMINISTRATOR"."PT_SYSLOG"  (
		  "IDS" VARCHAR(32) NOT NULL , 
		  "VERSION" BIGINT , 
		  "STARTDATE" TIMESTAMP , 
		  "STARTTIME" BIGINT , 
		  "ENDDATE" TIMESTAMP , 
		  "ENDTIME" BIGINT , 
		  "ACTIONENDDATE" TIMESTAMP , 
		  "ACTIONENDTIME" BIGINT , 
		  "ACTIONSTARTDATE" TIMESTAMP , 
		  "ACTIONSTARTTIME" BIGINT , 
		  "ACTIONHAOSHI" BIGINT , 
		  "VIEWHAOSHI" BIGINT , 
		  "HAOSHI" BIGINT , 
		  "CAUSE" CHAR(1) , 
		  "COOKIE" CLOB(1048576) LOGGED NOT COMPACT , 
		  "DESCRIPTION" CLOB(1048576) LOGGED NOT COMPACT , 
		  "IPS" VARCHAR(128) , 
		  "METHOD" VARCHAR(4) , 
		  "REFERER" VARCHAR(500) , 
		  "REQUESTPATH" CLOB(1048576) LOGGED NOT COMPACT , 
		  "STATUS" CHAR(1) , 
		  "USERAGENT" CLOB(1048576) LOGGED NOT COMPACT , 
		  "OPERATORIDS" VARCHAR(32) , 
		  "ACCEPT" VARCHAR(200) , 
		  "ACCEPTENCODING" VARCHAR(200) , 
		  "ACCEPTLANGUAGE" VARCHAR(200) , 
		  "CONNECTION" VARCHAR(200) , 
		  "HOST" VARCHAR(200) , 
		  "XREQUESTEDWITH" VARCHAR(200) , 
		  "PVIDS" VARCHAR(32) , 
		  "USERIDS" VARCHAR(32) )   
		 IN "USERSPACE1" ; 


-- ���������� DDL ��� "ADMINISTRATOR"."PT_SYSLOG"

ALTER TABLE "ADMINISTRATOR"."PT_SYSLOG" 
	ADD PRIMARY KEY
		("IDS");









COMMIT WORK;

CONNECT RESET;

TERMINATE;

