package com.baidu.ueditor.upload;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.baidu.ueditor.PathFormat;
import com.baidu.ueditor.define.AppInfo;
import com.baidu.ueditor.define.BaseState;
import com.baidu.ueditor.define.FileType;
import com.baidu.ueditor.define.State;
import com.oreilly.servlet.multipart.FilePart;
import com.oreilly.servlet.multipart.MultipartParser;
import com.oreilly.servlet.multipart.Part;

public class BinaryUploader {

	public static final State save(HttpServletRequest request, Map<String, Object> conf) {
		boolean isAjaxUpload = request.getHeader("X_Requested_With") != null;

		//return new BaseState(false, AppInfo.NOT_MULTIPART_CONTENT);

		if (isAjaxUpload) {
			//upload.setHeaderEncoding("UTF-8");
		}

		try {
			// 设置上传文件最大限度
			MultipartParser mp = null;
			try {
				mp = new MultipartParser(request, 1024 * 1024 * 10 * 2);
			} catch (Exception e) {
				request.setAttribute("errorInfo", "上传文件失败");
				return new BaseState(false, AppInfo.NOT_MULTIPART_CONTENT);
			}
			
			String savePath = (String) conf.get("savePath");
			
			// 代表一个file
			Part part = null;
			while ((part = mp.readNextPart()) != null) {
				// 获取表单名
				//String fieldName = part.getName();
				// 如果是文件域
				if (part.isFile()) {
					// 取得上传的该文件
					FilePart filePart = (FilePart) part;
					String fileName = filePart.getFileName();
					if (fileName != null && !"".equals(fileName)) {
						//filePart.getContentType()
						
						String originFileName = fileName;
						String suffix = FileType.getSuffixByFilename(originFileName);

						originFileName = originFileName.substring(0, originFileName.length() - suffix.length());
						savePath = savePath + suffix;

						long maxSize = ((Long) conf.get("maxSize")).longValue();

						if (!validType(suffix, (String[]) conf.get("allowFiles"))) {
							return new BaseState(false, AppInfo.NOT_ALLOW_FILE_TYPE);
						}

						savePath = PathFormat.parse(savePath, originFileName);

						String physicalPath = (String) conf.get("rootPath") + savePath;
						
						File file = new File(physicalPath);
						if(!file.getParentFile().exists()){
							file.getParentFile().mkdirs();
						}
						long size = filePart.writeTo(file);// 将文件写入硬盘
						if(size > maxSize){
							// 文件大小超过限制
						}
						
						State state = new BaseState(true);
						state.putInfo( "size", size );
						state.putInfo( "title", originFileName );
						
						state.putInfo( "url", PathFormat.format(savePath));
						state.putInfo(" type", suffix);
						state.putInfo( "original", originFileName + suffix);
						
						return state;
					} else {// 表示没有文件
						System.out.println("没有文件");
					}
				}
			}

			//return new BaseState(false, AppInfo.NOTFOUND_UPLOAD_DATA);
			
		} catch (IOException e) {
			
		}
		
		return new BaseState(false, AppInfo.IO_ERROR);
	}

	private static boolean validType(String type, String[] allowTypes) {
		List<String> list = Arrays.asList(allowTypes);

		return list.contains(type);
	}
}
