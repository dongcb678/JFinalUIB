package hprose.exam.client;

public enum Sex {
    Unknown, Male, Female, InterSex
}